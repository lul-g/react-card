import React, {useState} from 'react'

export default function Item(props) {
    return (
        <div className="item">{props.item}</div>
    )
}
